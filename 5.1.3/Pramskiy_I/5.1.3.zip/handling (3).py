import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def func_lin(x, k, b):
    return k * x + b
R = 1e5 # кОм

# U_n = '2.64'

# df = pd.read_excel('U_'+ U_n + '.xlsx')


# y = df['V_a'] / R # мА
# x = df['V']       # В 

# popt_lin, pcov_lin = curve_fit(func_lin, x, y)

# print(popt_lin)
# print(pcov_lin)
# print(np.sqrt(np.diag(pcov_lin)))

# plt.figure()
# plt.grid()
# plt.plot(x, y, 'ko', markersize=4)
# # x_plt = np.linspace(x.min(), x.max(), 50)

# # plt.errorbar(x, y, c='k', fmt='s', markersize=1, yerr=yerr)

# # plt.plot(x_plt, func_lin(x_plt , *popt_lin), 'k-', label="y = $k \cdot x + b$")
# plt.ylabel("$I_a$, мА")
# plt.xlabel("$U$, В")
# plt.title("График зависимости $I_a$ от $U$")
# plt.legend()
# plt.show()
# plt.savefig(type + '_' + size_mm[1] + '.png')

def plt_I_V(U, t):
    df = pd.read_excel('U_'+ U + '.xlsx')
    y = (df['V_a'] / R)[:-3] # мА
    x = df['V'][:-3]       # В 
    ind_min = y[y.argmax() : ].argmin() + y.argmax()

    print(f'U_нак = {U} В: U_max = {x[y.argmax()]:.3f} В, I_a = {y.max():.3f} мА')
    print(f'U_нак = {U} В: U_min = {x[ind_min]:.3f} В, I_a = {y[ind_min]:.3f} мА')

    plt.plot(x, y, t, markersize=4, label='$U_{нак}$ = ' + U + ' В')
    plt.ylabel("$I_a$, мкА")
    plt.xlabel("$U$, В")
    plt.title("График зависимости $I_a$ от $U$ ($U_{нак}$ =" + f" {U} В)")

    # plt.legend()
    # plt.show()
    # plt.savefig(type + '_' + size_mm[1] + '.png')


def plt_both_I_V():
    plt.figure()
    plt.grid()
    # plt_I_V('2.63', 'ko')
    plt_I_V('2.5', 'ks')
    plt.show()
    return
    plt.legend()
    # plt.savefig('I_a_U.png')

def plt_ln_Ia(U):
    df = pd.read_excel('U_'+ U + '.xlsx')
    y = -np.log(df['V_a'] / R) 
    x = df['V']       # В 
    plt.figure()
    plt.grid()
    plt.plot(x, y, 'ko', markersize=4)
    plt.ylabel("C $\omega$")
    plt.xlabel("$U$, В")
    plt.title("График зависимости $C \omega$ от $U$ ($U_{нак}$ = " + U + ' В)')
    plt.show()

def get_l(E1, E2, U0):
    h = 6.626 * 1e-34
    m = 9.10938 * 1e-31
    e = 1.602 * 1e-19

    l1 = h/(2 * (2 * m * e * (E1 + U0)) ** 0.5)
    l2 = 3 * h / (4 * (2 * m * e * (E2 + U0))** 0.5)
    l3 = h * 5**0.5 /(32 * m * e * (E2 - E1))** 0.5

    U0 = (4 * E2) / 5 - (9 * E1) / 5

    print(f'{l1 = }')
    print(f'{l2 = }')
    print(f'{l3 = }')
    print(f'{U0 = }')



if __name__ == '__main__':
    # plt_both_I_V()
    plt_ln_Ia('2.5')
    # get_l(E1=1.69, E2=5.133, U0=2.5) # 2.64 дин
    # get_l(E1=1.79, E2=5.96, U0=2.5) # 3.02 дин
    # get_l(E1=1.4, E2=6.3, U0=2.5) # 2.64 стат
    # get_l(E1=3.6, E2=9.6, U0=2.5) # 3.02 стат
    