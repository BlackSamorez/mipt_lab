import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.interpolate import make_interp_spline, BSpline
from scipy.optimize import curve_fit

def func_lin(x, k, b):
    return k * x + b

a = pd.read_excel('./5.4.2.xlsx')
# print(a)

a.drop(1, inplace=True)
x = a['J, A']
y = a['N-Nф']
x1 = a['p, кэВ/с']
x2 = a['T, кэВ']
y2 = a['mkFermi']
plt.figure(figsize=(12,8))
plt.scatter(x2, y2, s=10)

popt_lin, pcov_lin = curve_fit(func_lin, x2[5:20], y2[5:20])
y2err = y2 * (np.sqrt((1/2 * (np.sqrt(a['N'].values) ** (-1))) ** 2 + (3/2 * 0.05 / x.values) ** 2))
print(popt_lin, np.sqrt(np.diag(pcov_lin)))
print(-popt_lin[1]/popt_lin[0])
x_plt = np.linspace(x2[5], x2[20], 50)
plt.plot(x_plt, func_lin(x_plt , *popt_lin), 'r-.', label="y = $k \cdot x + b$")
plt.errorbar(x=x2, y=y2, yerr=y2err, linewidth=0, elinewidth=1, capsize=5)


# plt.scatter(x2, y)

plt.grid()
plt.title('График зависимости mkFermi от T')
plt.xlabel('T, кЭв')
plt.ylabel('mkFermi')
plt.show()
# x = np.array([5331,5341,5401,5852,5882,5945,5976,6030,6074,6096,6143,6164,6217,6267,6305,6334,6383,6402,6507,6533,6599,6678,6717,6929,7032])
# y = np.array([2205,2212,2254,2513,2529,2560,2574,2600,2618,2628,2649,2658,2682,2702,2719,2731,2750,2759,2798,2806,2833,2860,2873,2944,2972])

# plt.scatter(x, y)
# # plt.plot(x, y)
# plt.show()