import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import make_interp_spline, BSpline

x = np.array([5331,5341,5401,5852,5882,5945,5976,6030,6074,6096,6143,6164,6217,6267,6305,6334,6383,6402,6507,6533,6599,6678,6717,6929,7032])
y = np.array([2205,2212,2254,2513,2529,2560,2574,2600,2618,2628,2649,2658,2682,2702,2719,2731,2750,2759,2798,2806,2833,2860,2873,2944,2972])

plt.scatter(x, y)
# plt.plot(x, y)
x_new = np.linspace(x.min(), x.max(), 200)
spl = make_interp_spline (x, y, k= 3 )
y_new = spl(x_new)
# plt.c
plt.plot(x_new, y_new, c='r')
plt.title('График зависимости $\lambda$ от φ')
plt.xlabel('φ')
plt.ylabel('$\lambda$,$\AA$')
plt.show()